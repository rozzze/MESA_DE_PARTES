
<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH /Users/isac/LARAVEL/MESA_DE_PARTES/vendor/livewire/flux/src/../stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>