<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
    <div class="flex h-10 w-100 flex-1 flex-col gap-4 rounded-xl">
        <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Bienvenido, <?php echo e(auth()->user()->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>

        <?php $__currentLoopData = auth()->user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal0638ebfbd490c7a414275d493e14cb4e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::text','data' => ['class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2']); ?>Tu rol es: <?php echo e($role); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $attributes = $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $component = $__componentOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="flex flex-wrap gap-4 mt-6">
        <a href="<?php echo e(route('docrequest.create')); ?>" class="relative inline-flex items-center justify-center p-0.5 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-teal-300 to-lime-300 dark:text-white dark:hover:text-gray-900 focus:ring-4 focus:outline-none focus:ring-lime-200 dark:focus:ring-lime-800">
            <span class="relative px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-transparent group-hover:dark:bg-transparent">
                Crear Solicitud
            </span>
        </a>

        <?php if(auth()->user()->hasRole('ADMIN')): ?>
            <a href="<?php echo e(route('documentreviews.index')); ?>" class="inline-block text-white bg-blue-600 hover:bg-blue-700 px-5 py-2.5 rounded-lg font-medium">
                Revisión de Solicitudes
            </a>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <div class="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <p class="text-sm text-gray-500 dark:text-gray-400">Solicitudes Totales</p>
            <p class="text-2xl font-bold text-gray-800 dark:text-white">
                <?php echo e(\App\Models\DocumentRequest::count()); ?>

            </p>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <p class="text-sm text-gray-500 dark:text-gray-400">Aprobadas</p>
            <p class="text-2xl font-bold text-green-600">
                <?php echo e(\App\Models\DocumentRequest::where('estado', 'aprobado')->count()); ?>

            </p>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <p class="text-sm text-gray-500 dark:text-gray-400">Rechazadas</p>
            <p class="text-2xl font-bold text-red-600">
                <?php echo e(\App\Models\DocumentRequest::where('estado', 'rechazado')->count()); ?>

            </p>
        </div>
    </div>


    
    <div class="grid grid-cols-1 mb-8">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-semibold text-gray-800 mb-4">Distribución de Solicitudes por Estado</h2>
            <canvas id="solicitudesChart" class="max-h-96"></canvas>
        </div>
    </div>

    
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Función para inicializar o actualizar el gráfico
            function initializeChart() {
                const ctx = document.getElementById('solicitudesChart');

                if (ctx) {
                    // Destruir cualquier instancia de Chart.js existente en este canvas
                    if (window.solicitudesChartInstance) {
                        window.solicitudesChartInstance.destroy();
                    }

                    const data = {
                        pendiente: <?php echo e(\App\Models\DocumentRequest::where('user_id', auth()->id())->where('estado', 'pendiente')->count()); ?>,
                        aprobado: <?php echo e(\App\Models\DocumentRequest::where('user_id', auth()->id())->where('estado', 'aprobado')->count()); ?>,
                        rechazado: <?php echo e(\App\Models\DocumentRequest::where('user_id', auth()->id())->where('estado', 'rechazado')->count()); ?>

                    };

                    window.solicitudesChartInstance = new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: ['Pendiente', 'Aprobado', 'Rechazado'],
                            datasets: [{
                                label: 'Cantidad de Solicitudes',
                                data: [data.pendiente, data.aprobado, data.rechazado],
                                backgroundColor: [
                                    'rgba(255, 206, 86, 0.8)',
                                    'rgba(75, 192, 192, 0.8)',
                                    'rgba(255, 99, 132, 0.8)'
                                ],
                                borderColor: [
                                    'rgba(255, 206, 86, 1)',
                                    'rgba(75, 192, 192, 1)',
                                    'rgba(255, 99, 132, 1)'
                                ],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'top',
                                    labels: {
                                        boxWidth: 20
                                    }
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            let label = context.label || '';
                                            if (label) {
                                                label += ': ';
                                            }
                                            if (context.parsed !== null) {
                                                label += context.parsed + ' solicitudes';
                                            }
                                            return label;
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }

            // 1. Ejecutar cuando el DOM está completamente cargado (para la primera carga de la página)
            document.addEventListener('DOMContentLoaded', initializeChart);

            // 2. Ejecutar cuando Livewire navega (para navegaciones SPA)
            document.addEventListener('livewire:navigated', initializeChart);
        </script>
    <?php $__env->stopPush(); ?>

    
    <div class="mt-10 bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h2 class="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Últimas Solicitudes</h2>
        <ul class="space-y-2 text-gray-700 dark:text-gray-300">
            <?php $__currentLoopData = \App\Models\DocumentRequest::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="border-b pb-2">
                    <?php echo e($solicitud->user->name); ?> solicitó <strong><?php echo e($solicitud->documentType->nombre); ?></strong>
                    <span class="text-sm text-gray-500">(<?php echo e($solicitud->created_at->format('d/m/Y H:i')); ?>)</span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/isac/LARAVEL/MESA_DE_PARTES/resources/views/dashboard.blade.php ENDPATH**/ ?>